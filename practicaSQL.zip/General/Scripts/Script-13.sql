CREATE TABLE practica1.datos_produccion (
	datos_produccion_id int(11) auto_increment NOT NULL,
	fecha date NOT NULL,
	op int(10) DEFAULT NULL NULL,
	item int(10) DEFAULT NULL NULL,
	nombre_pedido varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL NULL,
	folio int(10) NOT null
	PRIMARY KEY (datos_produccion_id)
)
