insert into practica.datos_produccion ( 	id_produccion_P ,Fecha ,Op,Item , Nombre_producto , Total_cant_producto ,Valor_hora) 
values ('1005','2023-11-13','44100','1.2','Batiente','35','181.17');