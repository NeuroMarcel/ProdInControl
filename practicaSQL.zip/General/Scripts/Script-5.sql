-- practica.datos_produccion definition
drop table 'datos_produccion'
CREATE TABLE `datos_produccion` (
  `produccion_id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `Op` int(10) DEFAULT NULL,
  `item` int(10) DEFAULT NULL,
  `nombre_pedido` varchar(20) DEFAULT NULL,
  `total_cant_productos` int(10) DEFAULT NULL,
  `Op_trabajo` int(11) NOT NULL,
  PRIMARY KEY (`produccion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8mb4_general_ci;