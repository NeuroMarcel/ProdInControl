
-- drop table proceso_maquina_fk;
CREATE TABLE proceso_maquina_fk (
  proceso_maquina_fk_id int(11) NOT NULL AUTO_INCREMENT,
  maquina_id int(11) NOT NULL,
  procesos_id int(11) NOT NULL,
  PRIMARY KEY (proceso_maquina_fk_id)
  ,CONSTRAINT proceso_maquina_fk FOREIGN KEY (procesos_id) REFERENCES procesos (proceso_id) ON DELETE NO ACTION ON UPDATE NO action  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;