-- SELECT x.* FROM practica.maquina_procesos_fk x

select p.procesos_id ,p.nombre_proceso from practica.maquina_procesos_fk x
left join practica.procesos p on p.procesos_id = x.procesos_id 
left join practica.maquina m on m.maquina_id = x.maquina_id where x.procesos_id  = 3

