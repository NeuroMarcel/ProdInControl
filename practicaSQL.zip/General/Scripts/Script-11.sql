
drop table datos_cliente 

CREATE TABLE datos_cliente (
  datos_cliente_id int(11) NOT NULL AUTO_INCREMENT,
  Nombre_cliente varchar(100) NOT NULL,
  Direccion varchar(100) NOT NULL,
  PRIMARY KEY (datos_cliente_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;