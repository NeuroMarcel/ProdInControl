ALTER TABLE practica.procesos ADD unidad_medida varchar(10) NOT NULL;
