
alter table practica.datos_produccion 
modify column item Float;