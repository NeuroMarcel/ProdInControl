


  
CREATE TABLE procesos (
  proceso_id int(11) NOT NULL AUTO_INCREMENT,
  nombre_proceso varchar(40) NOT NULL,
  num_operadores int(2) DEFAULT NULL,
  tiempo int(10) DEFAULT NULL,
  nombre_pedido varchar(20) DEFAULT NULL,
  PRIMARY KEY (proceso_id)
) ENGINE=InnoDB ;

