select col from practica.datos_cliente dc 
where Nombre_Cliente insert new 'Cristobal Mardones'