SELECT w.procesos_id ,w.nombre_proceso  FROM practica.proceso_maquina_fk x 
left join practica.procesos w on w.procesos_id = x.procesos_id 
left join practica.maquina z on z.maquina_id = x.maquina_id 

