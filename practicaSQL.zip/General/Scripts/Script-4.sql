select x.*,w.direccion, w.Nombre_Cliente  from practica.datos_produccion x
left join practica.datos_cliente w on w.id_Cliente = x.datos_clientes_id;