-- practica1.proceso_maquina_fk definition

SELECT w.procesos_id ,w.nombre_proceso  FROM practica1.proceso_maquina_fk x 
left join practica1.procesos w on w.procesos_id = x.procesos_id 
left join practica1.maquina z on z.maquina_id = x.maquina_id 
where x.maquina_id = $value 
